/* ===========================================================
   Peelhouse — shared footer markup, injected on every page
   =========================================================== */

document.addEventListener("DOMContentLoaded", () => {
  const mount = document.getElementById("footer-mount");
  if(!mount) return;
  mount.innerHTML = `
    <div class="footer-grid">
      <div>
        <div class="logo"><span class="logo-mark" aria-hidden="true"></span><span class="display">Peelhouse</span></div>
        <p style="margin-top:10px; font-size:0.88rem; color:var(--muted); max-width:280px;">Made for the people who decorate everything. Small-batch vinyl stickers, packed by hand.</p>
      </div>
      <div>
        <h4>Shop</h4>
        <ul>
          <li><a href="shop.html">All stickers</a></li>
          <li><a href="shop.html?cat=cute">Cute & characters</a></li>
          <li><a href="shop.html?cat=funny">Funny & meme</a></li>
          <li><a href="shop.html?cat=aesthetic">Aesthetic & minimal</a></li>
        </ul>
      </div>
      <div>
        <h4>Help</h4>
        <ul>
          <li><a href="shipping.html">Shipping</a></li>
          <li><a href="returns.html">Returns</a></li>
          <li><a href="faq.html">FAQ</a></li>
          <li><a href="contact.html">Contact us</a></li>
        </ul>
      </div>
      <div>
        <h4>Peelhouse</h4>
        <ul>
          <li><a href="about.html">About</a></li>
          <li><a href="terms.html">Terms</a></li>
          <li><a href="privacy.html">Privacy</a></li>
        </ul>
      </div>
    </div>
    <div class="footer-bottom">
      <span>© 2026 Peelhouse. All stickers, no regrets.</span>
      <span>Made in Chandigarh, India 🇮🇳</span>
    </div>
  `;
});
