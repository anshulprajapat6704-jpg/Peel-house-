/* ===========================================================
   Peelhouse — cart logic (localStorage-backed, shared across pages)
   =========================================================== */

const CART_KEY = "peelhouse_cart";

function readCart(){
  try{
    const raw = localStorage.getItem(CART_KEY);
    return raw ? JSON.parse(raw) : {};
  }catch(e){
    return {};
  }
}

function writeCart(cart){
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartBadge();
}

function addToCart(id, qty = 1){
  const cart = readCart();
  cart[id] = (cart[id] || 0) + qty;
  writeCart(cart);
}

function setCartQty(id, qty){
  const cart = readCart();
  if(qty <= 0){
    delete cart[id];
  }else{
    cart[id] = qty;
  }
  writeCart(cart);
}

function removeFromCart(id){
  const cart = readCart();
  delete cart[id];
  writeCart(cart);
}

function cartCount(){
  const cart = readCart();
  return Object.values(cart).reduce((sum, q) => sum + q, 0);
}

function cartTotal(){
  const cart = readCart();
  let total = 0;
  for(const id in cart){
    const s = getSticker(id);
    if(s) total += s.price * cart[id];
  }
  return total;
}

function updateCartBadge(){
  document.querySelectorAll(".cart-count").forEach(el => {
    el.textContent = cartCount();
  });
}

let _toastTimer;
function showToast(msg){
  const toast = document.getElementById("toast");
  if(!toast) return;
  toast.textContent = msg;
  toast.classList.add("show");
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => toast.classList.remove("show"), 1800);
}

/* ---------- shared header behaviour ---------- */
document.addEventListener("DOMContentLoaded", () => {
  updateCartBadge();

  const toggle = document.querySelector(".nav-toggle");
  const nav = document.querySelector("nav.main");
  if(toggle && nav){
    toggle.addEventListener("click", () => {
      nav.classList.toggle("open");
      const isOpen = nav.classList.contains("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }
});
