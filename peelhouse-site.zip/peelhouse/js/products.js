/* ===========================================================
   Peelhouse — product catalog
   Single source of truth for every page (home, shop, product, cart)
   =========================================================== */

const STICKERS = [
  { id:"spike",        emoji:"🌵", name:"Spike",            tag:"Cute",      cat:"cute",      price:50,  bg:"var(--green)",  desc:"A small cactus with a big personality. Waterproof vinyl, 6.5cm." },
  { id:"froggy-mood",  emoji:"🐸", name:"Froggy Mood",       tag:"Cute",      cat:"cute",      price:45,  bg:"var(--green)",  desc:"For days when you feel a bit pond-shaped. Matte vinyl, 6cm." },
  { id:"unhinged-uni", emoji:"🦄", name:"Unhinged Unicorn",  tag:"Cute",      cat:"cute",      price:50,  bg:"var(--pink)",   desc:"Not all unicorns are gentle. Glossy vinyl, 7cm." },
  { id:"its-fine",     emoji:"😭", name:"It's Fine",         tag:"Funny",     cat:"funny",     price:45,  bg:"var(--yellow)", desc:"The official sticker of deadline week. Matte vinyl, 6cm." },
  { id:"this-is-fine", emoji:"🔥", name:"This Is Fine",      tag:"Funny",     cat:"funny",     price:45,  bg:"var(--pink)",   desc:"A classic for the chronically calm-on-the-outside. Glossy vinyl, 6.5cm." },
  { id:"glitch-gremlin",emoji:"👾",name:"Glitch Gremlin",    tag:"Funny",     cat:"funny",     price:50,  bg:"var(--blue)",   desc:"Lives in your laptop, causes minor chaos. Holographic vinyl, 6cm." },
  { id:"soft-focus",   emoji:"✨", name:"Soft Focus",        tag:"Aesthetic", cat:"aesthetic", price:60,  bg:"#fff",          desc:"Minimal sparkle for minimal surfaces. Clear vinyl, 5.5cm." },
  { id:"night-owl",    emoji:"🌙", name:"Night Owl",         tag:"Aesthetic", cat:"aesthetic", price:60,  bg:"var(--blue)",   desc:"For the 2am thinkers and late-night scrollers. Matte vinyl, 6cm." },
  { id:"quiet-mark",   emoji:"🤍", name:"Quiet Mark",        tag:"Aesthetic", cat:"aesthetic", price:55,  bg:"#fff",          desc:"Says nothing, means everything. Clear vinyl, 5cm." },
  { id:"mushy-vibes",  emoji:"🍄", name:"Mushy Vibes",       tag:"Nature",    cat:"nature",     price:45,  bg:"var(--yellow)", desc:"Forest-floor energy for your water bottle. Glossy vinyl, 6cm." },
  { id:"tidepool",     emoji:"🌊", name:"Tidepool",          tag:"Nature",    cat:"nature",     price:50,  bg:"var(--blue)",   desc:"A little wave for people who miss the coast. Glossy vinyl, 7cm." },
  { id:"cherry-on-top",emoji:"🍒", name:"Cherry On Top",     tag:"Nature",    cat:"nature",     price:45,  bg:"var(--pink)",   desc:"Sweet, small, and a little bit extra. Matte vinyl, 6cm." }
];

const CATEGORIES = [
  { id:"all",       label:"All stickers" },
  { id:"cute",      label:"Cute & characters" },
  { id:"funny",     label:"Funny & meme" },
  { id:"aesthetic", label:"Aesthetic & minimal" },
  { id:"nature",    label:"Nature & vibes" }
];

function getSticker(id){
  return STICKERS.find(s => s.id === id);
}
